# RUN

    py .trdt/dot.py
