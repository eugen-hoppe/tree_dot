# RUN

```python
python3 .trdt/dot.py
```

#### or

```python
py .trdt/dot.py
```
