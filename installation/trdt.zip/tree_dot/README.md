### RUN

```bash
python3 .trdt/dot.py
```

#### or

```bash
py .trdt/dot.py
```
