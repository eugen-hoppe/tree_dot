# Run


```bash
python3 trdt/dot.py
```

```bash
python trdt/dot.py
```

```bash
py trdt/dot.py
```
